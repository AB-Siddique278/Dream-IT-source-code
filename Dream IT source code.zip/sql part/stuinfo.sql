-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2021 at 06:03 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stuinfo`
--

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(10) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `courseName` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `transactionId` varchar(20) NOT NULL,
  `number` bigint(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `firstName`, `lastName`, `courseName`, `email`, `password`, `transactionId`, `number`) VALUES
(3, 'dsss', 'sdfdff', 'fdfdff', 'Hridoy', 'hridoy1911512560', ' fdfd', 122233),
(5, 'hRIDOY', 'mOLLHA', 'pROGRAMMING', 'Hridoy @GMAIL.COM', '111111', ' sdsdsdsdedd', 17898),
(36, 'hRIDOY', 'mOLLHA', 'pROGRAMMING', 'Hridoy', 'hridoy1911512560', ' sdsdsds', 21),
(42, 'ABsiddique', 'siddique', 'wordpress', 'Hridoy@gmail.com', 'dsdsdsds0213', ' hjsd123dds', 1789848646),
(46, 'hRIDOY', 'mOLLHA', 'wordpress', 'Hridoy@gmail.com', '123456', ' sdsdsdsdedd', 1789848),
(49, '', '', '', '', '', ' ', 0),
(50, 'Kamal', 'jamal', 'wordpress', 'kamal@gmail.com', '017899', ' hjsd123dds', 1789);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(10) NOT NULL,
  `Name` varchar(15) NOT NULL,
  `Email` varchar(15) NOT NULL,
  `registration` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `Name`, `Email`, `registration`) VALUES
(20, 'Kamal', 'Kamal@gmail.com', 'Ok'),
(100, 'rafi', 'sdsdsdsd@', 'Ok'),
(183, 'Monir hossin', 'Monir@gmail.com', 'Ok'),
(425, 'Rafi', 'rafi@gamil.com', 'Ok'),
(429, 'Muhaiminual', 'muhaiminual@gma', 'Ok'),
(439, 'Ashrif', 'ashrif@gmail.co', 'pending'),
(529, 'Pias', 'pias@gmail.com', 'Ok'),
(560, 'Abu Bakar', 'abu@gmail.com', 'Ok'),
(577, 'Mohtasim', 'Mohtasim@gmail.', 'pending');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12839;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
