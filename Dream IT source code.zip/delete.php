<?php
$id=$_GET['id'];
$con = mysqli_connect('localhost','root','','stuinfo');
$sql = "DELETE FROM student WHERE id=$id";
$result= mysqli_query($con, $sql);
header('Location: index.php');

?>