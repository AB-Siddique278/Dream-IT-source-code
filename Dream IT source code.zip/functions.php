

    <?php

    if (isset($_POST['firstName'])){

        $firstName = $_POST['firstName'];
        $lastName = $_POST['lastName'];
        $courseName = $_POST['courseName'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $transactionId =$_POST['transactionId'];
        $number = $_POST['number'];

    }
        $con = mysqli_connect('localhost','root','','stuinfo');
        $sql = "INSERT INTO registration VALUES (NULL, '$firstName','$lastName','$courseName','$email','$password',' $transactionId','$number')";
        $result = mysqli_query($con,$sql);
        
        
    ?>




<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <link rel="stylesheet" href="bootstrap.css">
    <title>Registration Form</title>
  </head>
  <body>
    <h1> </h1>



    <div class="container  ">
    <div class="row col-md-6 col-md-offset-3 bg-primary mt-5 text-white  mx-auto style="width: 200px;"             ">
      <div class="panel panel-primary">
        <div class="panel-heading text-center">
          <h1>Registration Form</h1>
        </div>
        <div class="panel-body">

        <form action=" " method="POST">
            <div class="form-group ">
              <label for="firstName">First Name</label>
              <input
                type="text"
                class="form-control"
                id="firstName"
                name="firstName"
              />
            </div>
            <div class="form-group">
              <label for="lastName">Last Name</label>
              <input
                type="text"
                class="form-control"
                id="lastName"
                name="lastName"
              />
            </div>


        </div>
        <div class="form-group">
          <label for="courseName">Course Name</label>
          <input
            type="text"
            class="form-control"
            id="courseName"
            name="courseName"
          />
        </div>




















        <!-- 

            <div class="form-group">
              <label for="gender">Gender</label>
              <div>
                <label for="male" class="radio-inline"
                  ><input
                    type="radio"
                    name="gender"
                    value="m"
                    id="male"
                  />Male</label
                >
                <label for="female" class="radio-inline"
                  ><input
                    type="radio"
                    name="gender"
                    value="f"
                    id="female"
                  />Female</label
                >
                <label for="others" class="radio-inline"
                  ><input
                    type="radio"
                    name="gender"
                    value="o"
                    id="others"
                  />Others</label
                >
              </div>
            </div>


            -->

                <div class="form-group">
                <label for="email">Email</label>
                <input
                    type="text"
                    class="form-control"
                    id="email"
                    name="email"
                />



                </div>
                <div class="form-group">
                <label for="password">Password</label>
                <input
                    type="password"
                    class="form-control"
                    id="password"
                    name="password"
                />





            </div>
            <div class="form-group">
              <label for="transactionId"> Payment With Transaction Id</label>
              <input
                type="transactionId"
                class="form-control"
                id="transactionId"
                name="transactionId"
              />








            </div>
            <div class="form-group">
              <label for="number">Phone Number</label>
              <input
                type="number"
                class="form-control"
                id="number"
                name="number"
              />
            </div>



        











        <br>
            <input type="submit" class="btn btn-warning" />


     </form>

        </div>
        <div class="panel-footer text-right">
          <small></small>
        </div>
      </div>
    </div>
  </div>
 <div class="toast" role="alert" aria-live="assertive" aria-atomic="true">
<div class="toast-header">
  <img src="..." class="rounded mr-2" alt="...">
  <strong class="mr-auto">Bootstrap</strong>
  <small>11 mins ago</small>
  <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<div class="toast-body">
  Hello, world! This is a toast message.
</div>
</div>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
    -->
  </body>
</html>