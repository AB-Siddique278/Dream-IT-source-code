

<?php

$con = mysqli_connect('localhost','root','','stuinfo');
$sql = "SELECT * FROM student";
$result= mysqli_query($con, $sql);

?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">

    <title>My projact</title>
  </head>
  <body>
  
    <div class="container">
        <div class="row clearfix">
            <div class= "col-md-2">
            <br>
                <a href="insert.php"class = "btn btn-success">Add Student</a>
            
            </div>
               
            <div class= "col-md-8"></div>
                <h1>Student Information</h1>
                <table class= "table table-bordered">
                
                    <thead>
                        <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Registration</th>
                        <th>Action</th>
                        
                        </tr>
                    </thead>

                <?php

                    while($row = mysqli_fetch_assoc($result)){
                ?>       
                        
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['Name']; ?></td>
                    <td><?php echo $row['Email']; ?></td>
                    <td><?php echo $row['registration']; ?></td>
                    <td>
                    <a class= "btn btn-primary btn-sm" href="Show.php?id=<?php echo $row['id']; ?>">View</a>
                    
                    <a class= "btn btn-info btn-sm" href="edit.php?id=<?php echo $row['id']; ?>">Edit</a>
                    <a class= "btn btn-danger btn-sm" href="delete.php?id=<?php echo $row['id']; ?>">Delete</a>
                    </td>
                 </tr>

                <?php } ?>
                </table>
    
        </div>
    
    
    
    </div>
    
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
    -->
  </body>
</html>



